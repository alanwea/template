# Dummy module for CPAN indexing purposes.
package W3C::LinkChecker;
use strict;
use vars qw($VERSION);
$VERSION = "4.81";
1;
